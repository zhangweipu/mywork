$(function () {
    $("li a").on("click",function () {
        alert("aa");
    })
})