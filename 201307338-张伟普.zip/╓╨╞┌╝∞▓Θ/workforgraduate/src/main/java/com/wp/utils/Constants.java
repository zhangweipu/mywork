package com.wp.utils;


/**
 * 存放一些数据常量和订单状态等
 * Created by zhang on 2017/3/16.
 */
public class Constants {
    public static final String ORDER_ND="ND";
    public static final String ORDER_DOING="DOING";
    public static final String ORDER_DONE="DONE";

    public static final String FOOD_ND="ND";
    public static final String FOOD_DOING="DOING";
    public static final String FOOD_DONE="DONE";

}
