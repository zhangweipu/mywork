package com.wp.utils;

/**
 * Created by zhang on 2017/3/16.
 */
public enum OrderState {
    ORDER_ND,ORDER_DOING,ORDER_DONE
}
