package com.wp.client.dao;

/**
 * Created by admin on 2016/10/5.
 */
public interface ClientDao {
}
